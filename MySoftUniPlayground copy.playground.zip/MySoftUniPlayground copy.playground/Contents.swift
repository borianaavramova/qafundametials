//: Playground - noun: a place where people can play

import UIKit
import Foundation

var str = "Hello, playground"

print("Helo, Swift")

print("Where are you from?")

var sideA = 6
var sideB = 8
print(sideA, sideB)
print(sideA*sideB)

var sideD = 7.7
var sideC = 8.34
print (sideD*sideC)

var perimeter = 2*sideA + 2*sideB
var surface = sideA*sideB
print(perimeter, surface)


var perimeterA = 2*sideD + 2*sideC
var surfaceA = sideD*sideC
print(perimeterA, surfaceA)

var sideX = 2
var sideY = 2.25
var aSum = Double(sideX) + Double(sideY)
print(aSum)

let studentName = "Boriana"
let studentSurname = "Avramova"
let facultyNumber = "123456"
let studentAge = 33
let averageMark = 5.83

let outputString = String(format: "%@\n%@\n%@\n%d\n%0.2f",
    studentName, studentSurname, facultyNumber, studentAge, averageMark)

print(outputString)


struct Student{
    var name : String
    var age : Int
    var facN : String
    var mark1 : Float
    var mark2 : Float
    var mark3 : Float
    
func averageMark() -> Float
    {
        let averageMarkForStudent:Float = (mark1 + mark2 + mark3)/3
        return averageMarkForStudent
    }
}

let firstStudent = Student(name: "Ivan", age : 33, facN : "23654", mark1 : 2.66, mark2 : 4.00, mark3 : 6.00)
let secondStudent = Student(name: "Stoian", age : 23, facN : "23655", mark1 : 5.66, mark2 : 4.00, mark3 : 6.00)
let thirdStudent = Student(name: "Dragan", age : 21, facN : "23656", mark1 : 5.50, mark2 : 5.50, mark3 : 6.00)

func compare(aStudent: Student, anotherStudent: Student) -> Student
{
    if(aStudent.averageMark() > anotherStudent.averageMark())
    
    {
    
        return firstStudent
    }
    
    else
    {
        return secondStudent
    }
}

let betterStudent1 = compare(aStudent:firstStudent, anotherStudent:secondStudent)
let betterStudent2 = compare(aStudent:firstStudent, anotherStudent:thirdStudent)

print(betterStudent2)
print(betterStudent1)

//print(averageMarkForStudent)



//Create structure describing a student, with name, faculty number, age, evaluation marks for 3 different subjects
//Make a function that accept as argument the above mentioned function and returns the average mark for the student.
//Create 5 different students and make an algorithm that is returning the name of the student with highest average mark

func greet(person:String) -> String
{
    let returnName = "Hallo, \(person)"
    return returnName
}

print(greet(person:"IZdislav"))


func createMail(fromPerson:String, toPerson:String, withSubject:String, mailMessage:String)-> String
{
    let sendMail = "To: \(toPerson)\nFrom: \(fromPerson)\nSubject: \(withSubject)\nBody: \(mailMessage)"
    return sendMail
}

print(createMail(fromPerson: "Boriana", toPerson: "Mi", withSubject: "Try to find out", mailMessage: "Neshto si tam da ima"))



//

func averageSpeedFor(tripLength: Double, duration: Double) -> Double
{
    return tripLength/duration
}

let averageSpeedInKmph = averageSpeedFor(tripLength: 370, duration: 2.3)
print(averageSpeedInKmph)

func convertToMPHFrom(averageSpeedInKmph: Double) -> Double
{
    return averageSpeedInKmph/1.609
}

let averageSpeedInMPH = convertToMPHFrom(averageSpeedInKmph: Double(averageSpeedInKmph))

print(averageSpeedInMPH)


func convertToMPS(kmph: Double) -> Double
{
    return kmph/3.6
}
let averageSpeedInMPS = convertToMPS(kmph: Double(averageSpeedInKmph))

print(averageSpeedInMPS)





/// lekciq
// Array - danni ot edi kakyv si tip, moje da ima dublirane na dannite vytre

let numbersOfNeshtoSi = [5, 9, 33, 58, 101, 280]
print(numbersOfNeshtoSi[5])


var invitedStudents = ["Alex", "Bobby" , "Vin", "Disel", "Mat"]
print(invitedStudents [0])


invitedStudents.append("Last One") // append = add element to the arrey
print(invitedStudents [5])

invitedStudents.remove(at: 3) //remove = remove element from the array
print(invitedStudents [3])

invitedStudents.index(of: "Mat")
//print(invitedStudents [5])


invitedStudents.removeAll()

invitedStudents.isEmpty

var numbersOfSth:[Int] = Array()
numbersOfSth.append(15)
numbersOfSth.append(21)
numbersOfSth.append(28)
numbersOfSth.append(contentsOf:[30, 35, 36, 68, 98])

print(numbersOfSth [5])


/// Set - garantira unikalnost na elementite vytre

var favouriteArtists: Set<String> = ["Tom Cruise", "Alek Boulduin", "Vin Disel", "Vin Disel"]
favouriteArtists.insert("Vin Disel")

print(favouriteArtists.sorted())

favouriteArtists.count

favouriteArtists.contains("Tom Cruise")


/// Dictioanry - nqkolko promenliwi, sybrani na edno mqsto - key + danny po key


var places: [String:(lat:Double, lon: Double)] = ["Sofia":(42.7, 23.3), "Viena":(90.3, 56.3), "Bora Bora":(12.36, 96.35)]

places["Sofia"]
places["Barcelona"] = (14.5, 85.3) //insert
places["Sofia"] = (42.65, 23.33) // modify

print(places.keys)
print(places.values)


// !!!!!! da go naucha mn dobreFOR - execute one code several times

let lotteryNumbers = [1, 5, 9, 13, 21, 56, 89]

for number in lotteryNumbers
{
    print("Current number\(number)")
}


var number:Int

number = lotteryNumbers[0]
number = lotteryNumbers[1]
number = lotteryNumbers[2]
number = lotteryNumbers[3]
number = lotteryNumbers[4]
number = lotteryNumbers[5]
number = lotteryNumbers[6]

// da naprawim edi kolko si pyti edno i syshto neshto

for index in 1...5
{
    print("Kakwo tolkova")
}


for index in 0..<6
{
    print("Kolkoto tolkova")
}

// ime : Kakyv e vidyt na pyrwata promenliva, viod na wtorata => for cycle

let animals:[String: Int] = ["Horse":4, "Goat": 2, "Spider": 8, "Human": 2]

for anAnimal in animals
{
    print("\(anAnimal.key) has \(anAnimal.value) legs")
}



//WHILE - pochti ne se izpolzwa... polzva se dokato se izchakva nqkakvo uslovie da se izpylni

var currentHour = 9

while currentHour < 17
{
    currentHour += 1 // tova se sluchva dokato onova gore e vqrno
}

// REPEAT WHILE - kato while, no zadyljitelno trqbwa da se mine pone vednyj prez operaciqta

var currentHour1 = 9

repeat
{
    currentHour += 1 // tova se sluchva dokato onova gore e vqrno
}

while (currentHour1 == 17)



// Conditiona operators - IF - can be only TRUE or FALSE

let persons: [String: Bool] = ["Ivan":true, "Peter":false, "Dim":true]

for person in persons
{
    if(person.value == true)
    {
        print("\(person.key), please enter")
    }
    
    else
    {
        print("\(person.key), please go home")
    }
}

func checkAge(age: Int) -> String
{
    if age < 14
    {
        return "Child"
    }
    
    else if age >= 14 && age < 18
    {
        return "Senior"
    }
    
    else if age >= 18
    {
        return "Adult"
    }
    
    return ""
}

checkAge(age: 7)


//HomeWork 1

func calculateAverageFuelConsumptionFor(tripLenght:Double, withConsumedLittres:Double)->Double
{
    return withConsumedLittres/tripLenght*100
}

let averageFuelConsumption = calculateAverageFuelConsumptionFor(tripLenght: 50, withConsumedLittres: 3.8)

print(averageFuelConsumption)


//3.78541 literes = 1 US gallon

func calculateAverageFuelConsumptionInMPG(averageFuelConsumptionInLiteres: Double) -> Double
{
    return averageFuelConsumptionInLiteres/3.78541
}

let averageFuelConsumptionInMPG = calculateAverageFuelConsumptionInMPG(averageFuelConsumptionInLiteres: Double(averageFuelConsumption))

print(averageFuelConsumptionInMPG)


// let onGivenPrice = 1.79
func calculateAveragePricePerKM(onGivenPrice: Double, withAverageFuelConsumption: Double ) -> Double
{
    return withAverageFuelConsumption*onGivenPrice
}

let averagePricePerKM = calculateAveragePricePerKM(onGivenPrice: 1.79, withAverageFuelConsumption: Double(averageFuelConsumption))

print(averagePricePerKM)


//HomeWork 2
// Snake and ladders: Игралната дъска има 25 полета - 5 реда и 5 колони.
// Допускаме, че стълбите са разположени на поле и водят до поле както следва:
// - 2 - води до 8
// - 5 - води до 14
// - 6 води до 16
// - 12 води до 23
// Допускаме, че змиите са разположени на поле и водят до поле както следва:
// - 13 води до 4
// - 18 води до 7
// - 21 води до 17
// - 24 води до 19


let finalSquareOnTheBoard = 25 // posledno pole
var boardSquare = [Int] (repeating: 0, count: finalSquareOnTheBoard + 1)

boardSquare[2] = +6
boardSquare[5] = +9
boardSquare[6] = +10
boardSquare[12] = +11
boardSquare[13] = -9
boardSquare[18] = -11
boardSquare[21] = -4
boardSquare[24] = -5

var currentSquare = 0
var rollTheDice = 0


var squareType:Int

let boardSquaresWithLadders = [2, 5, 6, 12]
let boardSquaresWithSnakes = [13, 18, 21, 24]

func playSnakesAndLadders()
{
    if currentSquare < finalSquareOnTheBoard
    {
        print("Roll the Dice!")
    }
    else
    {
        print("This is the end of the Game!")
    }
    
    repeat
    {
        currentSquare += boardSquare[currentSquare]
        rollTheDice = 1
        
        rollTheDice += 1
        currentSquare += rollTheDice
        
    }
        while currentSquare < finalSquareOnTheBoard
    
    if currentSquare < finalSquareOnTheBoard
    {
        print("Roll the Dice!")
    }
    else
    {
        print("This is the end of the Game!")
    }
}

playSnakesAndLadders()


/// SWITCH

let string = "fsekjfwelkfmvsd`kfoksfmskgvk;mvfkklskdmoaeiuyuuukHGhjJIjkfsegf3365fefkqkw"
var dict = [Character:Int]()

func checkAndIncrease(for char:Character)
{
    if let repeating = dict[char]
    {
        dict[char] = repeating + 1
    }
    else
    {
        dict[char] = 1
    }
}

for char in string.characters
{
    switch char
    {
    case "a":
        checkAndIncrease(for:"a")
    case "o":
        checkAndIncrease(for: "o")
    case "e":
        checkAndIncrease(for: "e")
    case "u":
        checkAndIncrease(for: "u")
    case "i":
        checkAndIncrease(for: "i")
    default:
        checkAndIncrease(for: "`")
    }
}

print(dict)


//Task 1 Belot game - calculate the points in a pile pri All Trumps
//7 = 0, 8 = 0, 10 = 10, Q = 3, K = 4, J = 20, 9 = 14, A = 11

let pile1 = ["7", "8", "J", "Q", "A", "10", "9", "K"]
let pile2 = ["K", "8", "J", "Q", "A", "10", "9", "K"]
let pile3 = ["J", "8", "J", "Q", "A", "10", "9", "K"]
let pile4 = ["A", "8", "J", "Q", "A", "10", "9", "K"]

func calculatePoints(inPile pile:[String]) -> Int
{
    
    var points = 0
    for card in pile
    {
        switch card
        {
        case "7":
            points += 0
        case "8":
            points += 0
        case "9":
            points += 14
        case "10":
            points += 10
        case "J":
            points += 20
        case "Q":
            points += 3
        case "K":
            points += 4
        case "A":
            points += 11
        default:
            points += 0
        }
    }
        return points
}

print(calculatePoints(inPile: pile1))
print(calculatePoints(inPile: pile2))
print(calculatePoints(inPile: pile3))
print(calculatePoints(inPile: pile4))


//sybiratelni neshta
let exactTimes = 782

switch exactTimes {
case 0:
    print("no")
case 1..<5:
    print("a few")
case 5..<12:
    print("several")
case 12:
    print("a dozen")
case 13..<100:
    print("something else")
default:
    print("any")
}

let somePoint = (-3,3)
switch somePoint {
case (0,0):
    print("center")
case (_, 0):
    print("on x axis")
case (0, _):
    print("on y axis")
case (-2...2, -2...2):
    print("close to center")
case (let x, let y) where x==y:
    print("diagonal")
default:
    print("somewhere")
}


//ENUMS
enum Planet{
    case Mercury
    case Venus
    case Earth
    case Mars
    case Jupiter
    case Saturn
    case Uranus
    case Neptune
}

let planet = Planet.Mars
switch planet
{
case .Mercury:
    print("0.4 AU")
case .Venus:
    print("0.7 AU")
case .Earth:
    print("1.0 AU")
case .Mars:
    print("1.5 AU")
case .Jupiter:
    print("5.2 AU")
case .Saturn:
    print("9.5 AU")
case .Uranus:
    print("19.2 AU")
case .Neptune:
    print("30.1 AU")
}

enum CompassDirections:String
{
    case North = "Север"
    case South = "Юг"
    case East = "Изток"
    case West = "Запад"
}

print(CompassDirections.East.rawValue)

enum Barcode
{
    case upc(Int,Int,Int,Int)
    case QRCode(String)
}
let barcode = Barcode.QRCode("I🍄")
    switch barcode {
    case .QRCode(let productCode):
    print(productCode)
    case .upc(let numberSystem, let manufacturer, let product, let check):
    print(numberSystem,manufacturer,product,check)
}


enum Planets:Int {
    case Mercury = 1, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
}
let aPlanet = Planets(rawValue: 3)
print(aPlanet)
print(Planets.Mars.rawValue)


//BREAK and Continue - find the wanted value and stop the func
let numbers =
    [1,2,4,5,1,2,4,7,3,2,6,1,73,927,74,42,827,75,81,25,94,27,48]
for number in numbers
{
    if number == 42
    {
        print("got it")
        break
    }
}

for aNumber in numbers
{
    if number != 42
    {
        continue
    }
    print("got it")
    break
}

let charackter = ["a", "j", "f", "k", "j", "k", "f", "l", "r", "g", "eor", "jnge", "rgb", "klkf", "dkjr", "gj", "win", "njk", "jkgxdfbn"]
for aCharacter in charackter
{
    if aCharacter == "win"
    {
        print("Found it!")
        break
    }
}


//FALLTHROUGH - prodylji napred da proverqvash dali otgovarq na usloviqta. Ako go nqma, kato stigne do uslovie, na koeto otgowarq - spira (break)
let anotherNumber = 13
switch anotherNumber {
case 11, 13, 15, 17, 19:
    print("More than 10")
    fallthrough
case 1,3,5,7,9:
    print("Odd number")
    fallthrough
case 13:
    print(13)
default:
    print("Even number or larger than 19")
}

// Make a Belot Game: card counter for two teams. The game must support All trump and No trump as well as Belote, tierce, quartet, quit, carre of J, K, Q, A, 9, 10.

let cardCounterForTeam1 = ["7", "8", "J", "Q", "A", "10", "9", "K"]
let cardCounterForTeam2 = ["K", "8", "J", "Q", "A", "10", "9", "K"]

func calculatePointsForTeam(inCounter cardCounterForTeam:[String]) -> Int
{
    
    var points = 0
    for card in cardCounterForTeam
    {
        switch card
        {
        case "7":
            points += 0
        case "8":
            points += 0
        case "9":
            points += 14
        case "10":
            points += 10
        case "J":
            points += 20
        case "Q":
            points += 3
        case "K":
            points += 4
        case "A":
            points += 11
        default:
            points += 0
        }
    }
    return points
}

print(calculatePoints(inPile: cardCounterForTeam1))
print(calculatePoints(inPile: cardCounterForTeam2))


//variant ot lekciqta
enum GameType:String
{
    case AllTrumps, NoTrumps
}

enum PlayingCards:String
{
    case J = "J"
    case c9 = "9"
    case A = "A"
    case K = "K"
    case Q = "Q"
    case c10 = "10"
    case c8 = "8"
    case c7 = "7"
    case Belote = "Belote"
    case Tierce = "Tierce"
    case Quartet = "Quartet"
    case Quint = "Quint"
    case CarreOfJ = "CarreOfJ"
    case CarreOf9 = "CarreOf9"
    case CarreOfA = "CarreOfA"
    case CarreOfK = "CarreOfK"
    case CarreOfQ = "CarreOfQ"
    case CarreOf10 = "CarreOf10"
}

func countPoints(for stringPile:[String], game: GameType) -> Int
{
    var pile = [PlayingCards]()
    for item in stringPile
    {
        if let aCard = PlayingCards(rawValue: item)
        {
            pile.append(aCard)
        }
        else
        {
            print ("Error: Item at index \(stringPile.index(of:item)) is not convertable to a card")
        }
    }
    return countPoints(for: pile, game: game)
}



func countPoints(for aTeam:[PlayingCards], game: GameType) -> Int
{
    var result = 0
    for aCard in aTeam
        
    {
        //let tuple = (aCard, game)
        switch aCard {
        case .A:
            result += 11
        case .K:
            result += 4
        case .Q:
            result += 3
        case .J where game == .AllTrumps:
            result += 20
        case .J where game == .NoTrumps:
            result += 2
        case .c10:
            result += 10
        case .c9 where game == .AllTrumps:
            result += 14
        case .Belote where game == .AllTrumps:
            result += 20
        case .Tierce where game == .AllTrumps:
            result += 30
        case .Quartet where game == .AllTrumps:
            result += 40
        case .Quint where game == .AllTrumps:
            result += 50
        case .CarreOfJ where game == .AllTrumps:
            result += 200
        case .CarreOf9 where game == .AllTrumps:
            result += 150
        case .CarreOfA where game == .AllTrumps:
            result += 100
        case .CarreOfK where game == .AllTrumps:
            result += 100
        case .CarreOfQ where game == .AllTrumps:
            result += 100
        case .CarreOf10 where game == .AllTrumps:
            result += 100
        default:
            break
        }
    }
        return result
}

    
let cardCounterForTeamA = ["CarreOfJ", "8", "J", "Q", "A", "10", "9", "K", "CarreOfK"]
let cardCounterForTeamB = ["K", "CarreOfJ", "J", "Q", "A", "10", "9", "K", "Belote"]
    
print(countPoints(for: cardCounterForTeamA, game: .AllTrumps))
print(countPoints(for: cardCounterForTeamB, game: .NoTrumps))



//HomeWork 2: Task 1: Cooking Recipes
//Създавам 3 рецепти - ябълков пай, чийзкейк и палачинки. ВНИМАНИЕ! Моля не използвайте рецептите за реално готвене. Само палачинките ще стават за ядене след това :)

enum CookingIngredient: String
{
    case Sugar = "Sugar"
    case Flour = "Flour"
    case Salt = "Salt"
    case Milk = "Milk"
    case Water = "Water"
    case Oil = "Oil"
    case Biscuits = "Biscuits"
    case SourCream = "SourCream"
    case WhiteCheese = "WhiteCheese"
    case CocounutSprinkles = "CocounutSprinkles"
    case Rum = "Rum"
    case Blueberries = "Blueberries"
    case Apples = "Apples"
    case Chocolate = "Chocolate"
    case Butter = "Butter"
    case Banana = "Banana"
}

enum QuantityType {
    
    case Gr, Ml, TeaCup, Packs, Bar
}

enum RecipeType {
    case ApplePie, CheeseCake, Pancakes
}

typealias RecipeItem = (ingredient: CookingIngredient, quantity: Double, quantityType: QuantityType)
typealias Recipe = (recipeType: RecipeType, ingridients: [RecipeItem])

let applePie: Recipe = ( .ApplePie,     [RecipeItem(.Flour, 500, .Gr),
                                         RecipeItem(.Sugar, 200, .Gr),
                                         RecipeItem(.Milk, 400, .Ml),
                                         RecipeItem(.Water, 100, .Ml),
                                         RecipeItem(.Apples, 500, .Gr),
                                         RecipeItem(.Chocolate, 1, .Bar),
                                         RecipeItem(.Butter, 1.5, .Packs)])

let cheeseCake: Recipe = ( .CheeseCake, [RecipeItem(.Biscuits, 2, .Packs),
                                         RecipeItem(.SourCream, 2, .Packs),
                                         RecipeItem(.WhiteCheese, 250, .Gr),
                                         RecipeItem(.CocounutSprinkles, 100, .Gr),
                                         RecipeItem(.Rum, 1000, .Ml),
                                         RecipeItem(.Blueberries, 250, .Gr),
                                         RecipeItem(.Butter, 2, .Packs)])

let pancakes: Recipe = ( .Pancakes,     [RecipeItem(.Flour, 1000, .Gr),
                                         RecipeItem(.Sugar, 10, .Gr),
                                         RecipeItem(.Salt, 10, .Gr),
                                         RecipeItem(.Milk, 250, .Ml),
                                         RecipeItem(.Water, 250, .Ml),
                                         RecipeItem(.Oil, 1.5, .TeaCup)])

let recipes = [applePie, cheeseCake, pancakes]

func searchForCookingIngredient(ingredient: CookingIngredient) -> [Recipe] {
    
    var result: [Recipe] = []
    
    for recipe in recipes {
        
        for item in recipe.ingridients {
            
            if item.ingredient == ingredient {
                
                result.append( recipe )
            }
        }
    }
    
    return result
}

let result = searchForCookingIngredient(ingredient: .Flour)

if result.isEmpty {
    print("No Recipies were found!")
}
else {
    for item in result {
        print("Recipe: \(item.recipeType)")
    }
}


//HomeWork 2: Task 2: What I should buy - what products must be bought and how many (how much)?
//Тъй като палачинките са едно от малкото неща, които реално мога да сготвя, проверявам кои продукти имам налични. Които нямам или имам недостатъчно количество, проверявам, изчислявам и тръгвам на пазар.

let availableIngredients = [RecipeItem(.Flour, 200, .Gr),
                            RecipeItem(.Salt, 1000, .Gr),
                            RecipeItem(.Water, 1250, .Ml),
                            RecipeItem(.Oil, 10, .TeaCup)]

func unavailableIngredientsForRecipe( recipe: Recipe ) -> [RecipeItem] {
    
    var unavailableIngredients: [RecipeItem] = []
    
    for ingredient in recipe.ingridients {
        
        var needed = ingredient
        
        for availableIngredient in availableIngredients {
            
            if availableIngredient.ingredient == ingredient.ingredient {
                needed.quantity -= availableIngredient.quantity
            }
        }
        
        if needed.quantity > 0 {
            unavailableIngredients.append(needed)
        }
    }
    
    return unavailableIngredients
}

let unavailableIngredients = unavailableIngredientsForRecipe(recipe: pancakes)

if unavailableIngredients.isEmpty {
    print("No need to buy anything. Start cooking!")
}
else {
    for item in unavailableIngredients {
        print("I need to buy:\nIngredient: \(item.ingredient) => \(item.quantity)\(item.quantityType)")
    }
}

//Make an Airport check-in system. It must have function that based on the name of person must provide ticket number. Each outgoing flight has container with all ticket numbers that are associated with this flight. Make a function that is printing information about all the persons that have already checked in for a flight and how many tickets have not been taken.


struct FlightTicketInfo{
    
    var nameOfPerson: String
    var ticketNumber: String
    var checkedIn: Bool
}

let flightVAR500 = [FlightTicketInfo(nameOfPerson: "Ivan",  ticketNumber: "A123", checkedIn: true),
                    FlightTicketInfo(nameOfPerson: "Petar", ticketNumber: "A124", checkedIn: false),
                    FlightTicketInfo(nameOfPerson: "Matt",  ticketNumber: "A125", checkedIn: true),
                    FlightTicketInfo(nameOfPerson: "Rin",   ticketNumber: "B126", checkedIn: false),
                    FlightTicketInfo(nameOfPerson: "Aiden", ticketNumber: "B127", checkedIn: true),
                    FlightTicketInfo(nameOfPerson: "Aiden", ticketNumber: "A127", checkedIn: true)]

func findTicketNumberForPersonWith( nameOfPerson: String ) -> [String] {
    
    var result: [String] = []
    
    for person in flightVAR500 {
        
        if(person.nameOfPerson == nameOfPerson){
            result.append(person.ticketNumber)
        }
    }
    
    return result
}

let name = "Aiden"

let aResult = findTicketNumberForPersonWith(nameOfPerson: name)

if aResult.isEmpty {
    print("No Passanger was found!")
}
    
else {
    for ticket in aResult {
        print("\(name): \(ticket)")
    }
}


func printFlightVAR500Info(){
    
    var ckeckedIn: [String] = []
    var notCheckedIn: [String] = []
    
    for person in flightVAR500 {
        
        if(person.checkedIn == true) {
            
            ckeckedIn.append(person.nameOfPerson)
        }
        else {
            
            notCheckedIn.append(person.nameOfPerson)
        }
    }
    
    print("Checked in: \(ckeckedIn)")
    
    print("Pending ckeckins \(notCheckedIn.count)")
    
    print("NOT Checked in: \(notCheckedIn)")
}

printFlightVAR500Info()


//closure
func requestDataFromServer(completion:(_ errorNumber:Int)->Void)
{
    completion(404)
}

func displayDataFromServer()
{
    print("Data from server displayed")
}

func doEverything()
{
    requestDataFromServer { (errorNumber ) in
        if errorNumber > 0
        {
            // execute someting when there is an error
            print("Server responded with error \(errorNumber)")
            return;
        }
        displayDataFromServer()
        // execute normal sequence
    }
}

doEverything()


//Swift Part III
//Classes and Objects

//class className{
//    var variable1: Type? // Optional property
//    var variable2: Type! // wrapped property
//    let const1: Type
//    let const2: Type
//
//    func aFunction(argumentOne: Type, argumentTwo: Type) -> ReturnType
//    {
//        return someValue
//    }
//}

class Human{
    var age: Int?
    
    func walk(){
    
    }
    
    func talk(){
        print("Hallo, Swift Part III")
    }
}

class MyFirstClass{
    
    var variable1: Int? // Optional variable
    var variable2: String! // wrapped variable
    let const1: Int
    
    init(var1:Int, var2: String, cons1: Int) {
        variable1 = var1
        variable2 = var2
        const1 = cons1
    }
    
    func printAll()
    {
        print(variable1!, variable2, const1)
    }
}

let anObject = MyFirstClass(var1: 15, var2: "Love", cons1: 5)

print(anObject.variable2)

anObject.printAll()

let anotherObject = MyFirstClass(var1: 15, var2: "Hates", cons1: 25)

anotherObject.printAll()

anotherObject.variable2 = "Loves"

anotherObject.printAll()


//Create a class ATM and class Human. The ATM must be initialized with amount of money available. The human must be initialized with name, and money available in his account.

class HumanWithBankAccount{
    var name: String!
    var accountBalance: Float!
    var availableMoney: Float?
    
    init(name:String,accountBalance: Float, availableMoney:Float) {
        self.name = name
        self.accountBalance = accountBalance
        self.availableMoney = availableMoney
    }
}

class ATM{
    var amountOfMoneyAvailable: Float!
    
    init(amountOfMoneyAvailable: Float) {
        self.amountOfMoneyAvailable = amountOfMoneyAvailable
    }
    
    func withdrawMoney(user:HumanWithBankAccount, amount: Float){
        
        if user.availableMoney! < amount {
            print("Not enogh money")
            return
        }
        
        if self.amountOfMoneyAvailable! < amount {
            print("Not enough money in ATM")
            return
        }
        
        self.amountOfMoneyAvailable! -= amount
        
        if let newAvailableMoney = user.availableMoney {
            user.availableMoney! = newAvailableMoney
        }
        else {
            user.availableMoney = amount
        }
    }
}

//A human walks to ATM and withdraw money. If the ATM cannot provide the amount, it sends a message, if the human has not enough remaining balance, the ATM sends a message, else the ATM provides money to the human.

let anATMMachine = ATM(amountOfMoneyAvailable: 100)
let person1 = HumanWithBankAccount(name: "Ivan", accountBalance: 1500.86, availableMoney: 1380.53)

anATMMachine.withdrawMoney(user: person1, amount: 400)

print(person1.availableMoney!)

let person2 = HumanWithBankAccount(name: "Petar", accountBalance: 500.86, availableMoney: 380.53)
anATMMachine.withdrawMoney(user: person2, amount: 400)

print(person2.availableMoney!)

//Create a class Car. The class car must has the following properties: Make, Model, Year of manufacture, HPS, Wheel drive type, 0-100 kmph time, price.

enum WheelDriveType{
    case front, rear
}

class Car{
    var make: String!
    var model: String!
    var yearOfManifacture: (year: Int, month: Int, day: Int)
    var hPS: Float!
    var wheelDriveType: WheelDriveType!
    var zeroPer100kphTime: Float!
    var price: Float!
    
    init(make: String,
         model: String,
         yearOfManifacture: (year: Int, month: Int, day: Int),
         hPS: Float,
         wheelDriveType: WheelDriveType,
         zeroPer100kphTime: Float,
         price: Float) {
        
        self.make = make
        self.model = model
        self.yearOfManifacture = yearOfManifacture
        self.hPS = hPS
        self.wheelDriveType = wheelDriveType
        self.zeroPer100kphTime = zeroPer100kphTime
        self.price = price
    }
}

//Task: Make another class called Comparator. It has the functions to evaluate 2 cars based on their properties.

class CarComparator{
    
    var car1: Car!
    var car2: Car!
    
    init(car1: Car, car2: Car){
        self.car1 = car1
        self.car2 = car2
    }
    
    func carWithMoreHPS() -> Car?{
        
        return CarComparator.carWithMoreHPS(car1: self.car1, car2: self.car2)
    }
    
    class func carWithMoreHPS(car1: Car, car2: Car) -> Car? {
    
        if car1.hPS > car2.hPS{
            return car1
        }
        
        else if car1.hPS < car2.hPS{
            return car2
        }
        
        else {
            return nil
        }
    }
    
    func newerCar() -> Car?{
       
        if car1.yearOfManifacture > car2.yearOfManifacture{
            return car1
        }
       
        else if car1.yearOfManifacture < car2.yearOfManifacture{
            return car2
        }
        
        else{
            return nil
        }
    }
    
    func cheaperCar() -> Car?{
    
        if car1.price < car2.price{
            return car1
        }
        else if car1.price > car2.price{
            return car2
        }
        
        else{
            return nil
        }
    }
}

let shkodaCitigo = Car(make: "Shkoda",
                       model: "Citigo",
                       yearOfManifacture: (year: 2015, month: 10, day: 30),
                       hPS: 550.0,
                       wheelDriveType: .rear,
                       zeroPer100kphTime: 5,
                       price: 24000.0)

let vwUp =         Car(make: "VW",
                       model: "Up",
                       yearOfManifacture: (year: 2015, month: 8, day: 15),
                       hPS: 650.0,
                       wheelDriveType: .rear,
                       zeroPer100kphTime: 6.3,
                       price: 44000.0)

let aComaparator = CarComparator(car1: shkodaCitigo, car2: vwUp)

print(aComaparator.carWithMoreHPS()!.make)
print(CarComparator.carWithMoreHPS(car1: shkodaCitigo, car2: vwUp)?.make! as Any)
print(aComaparator.newerCar()!.make)
print(aComaparator.cheaperCar()!.make)


/// Structure

struct Cars {
    var make: String!
    var model: String!
    var yearOfManifacture: (year: Int, month: Int, day: Int)
    var hPS: Float!
    var wheelDriveType: WheelDriveType!
    var zeroPer100kphTime: Float!
    var price: Float!
}

//Classes passes by reference.
//Structures passes by value.

//Inheritance
//You must implement a program for registering different vehicles. There are few main types of vehicles: Car, Motorcycle, Truck, Long Vehicle, Special Vehicle.

//The properties that each of the vehicle types are: Registration number, Engine, Hps, VIN number. The car has also number of seats, motorcycle - max speed, Truck and Long Vehicle - maximum load, Special Vehicle - special vehicle type and other information.

class Vehicle{
    
    let regNumber: String!
    let engine: Float!
    var hps: Float!
    let VIN: String!
    
    init(regNumber: String, engine: Float, hps:Float, VIN:String) {
        self.regNumber = regNumber
        self.engine = engine
        self.hps = hps
        self.VIN = VIN
    }
}

class InheritanceExampleCar: Vehicle{
    let numberOfSeats: Int
    
    init(regNumber: String, engine: Float, hps:Float, VIN:String, numberOfSeats: Int)
    {
        self.numberOfSeats = numberOfSeats
        super.init(regNumber: regNumber, engine: engine, hps: hps, VIN: VIN)
    }
}

let aCar = InheritanceExampleCar(regNumber: "123123", engine: 2.3, hps: 95, VIN: "asdasdads",
              numberOfSeats: 6)
print(aCar.regNumber)
print(aCar.numberOfSeats)


class InheritanceExampleSpecialVehicle: Vehicle{
    
    let type: String
    
    init(regNumber: String, engine: Float, hps:Float, VIN:String, type: String)
    {
        self.type = type
        super.init(regNumber: regNumber, engine: engine, hps: hps, VIN: VIN)
    }
}

let aSpecialVehicle = InheritanceExampleSpecialVehicle(regNumber: "4545455", engine: 2.3, hps: 95, VIN: "kkkkkkkkk",
                                            type: "Long Vehikle")

print(aSpecialVehicle.regNumber)
print(aSpecialVehicle.type)


//Make a new class called policemen. It accepts in the initialized an argument from type Vehicle and prints all the information available for this vehicle

class Policeman{
    
    var currentCheckedVehikle: Vehicle?
    
    init(currentCheckedVehikle: Vehicle) {
        self.currentCheckedVehikle = currentCheckedVehikle
    }
    
    func printVehikleInfo(){
        
        if let aVehicle = self.currentCheckedVehikle{
            
            print(aVehicle.regNumber)
            print(aVehicle.VIN)
            
            switch aVehicle {
            case is InheritanceExampleCar:
                print((aVehicle as! InheritanceExampleCar).numberOfSeats)
            case is InheritanceExampleSpecialVehicle:
                print((aVehicle as! InheritanceExampleSpecialVehicle).type)
            default: break
            }
        }
    }
}

let aPolicemen = Policeman(currentCheckedVehikle: aCar)

aPolicemen.printVehikleInfo()
aPolicemen.currentCheckedVehikle = aSpecialVehicle
aPolicemen.printVehikleInfo()

